#include <iostream>
#include <functional>

class LinkedList {
private:
    struct Node {
        int data;
        Node* next;
        Node(int val) : data(val), next(nullptr) {}
    };
    
    Node* head;
    size_t size;
    std::size_t cumulativeHash;  // To store the cumulative hash of the entire list

    // A simple polynomial rolling hash function
    static std::size_t hashFunction(int val) {
        return std::hash<int>{}(val);
    }

    // Update cumulative hash during insertion and deletion
    void updateHashInsert(int val) {
        cumulativeHash = cumulativeHash * 31 + hashFunction(val);  // Update hash when a new value is inserted
    }

    void updateHashDelete(int val) {
        cumulativeHash = cumulativeHash - hashFunction(val);  // Update hash when a value is deleted
    }

public:
    LinkedList() : head(nullptr), size(0), cumulativeHash(0) {}

    // Insert a new element at the end of the list
    void insert(int val) {
        Node* newNode = new Node(val);
        if (!head) {
            head = newNode;
        } else {
            Node* temp = head;
            while (temp->next) {
                temp = temp->next;
            }
            temp->next = newNode;
        }
        updateHashInsert(val);
        size++;
    }

    // Search for an element in the list
    bool search(int val) {
        Node* temp = head;
        while (temp) {
            if (temp->data == val) return true;
            temp = temp->next;
        }
        return false;
    }

    // Delete an element from the list
    bool remove(int val) {
        if (!head) return false;

        Node* temp = head;
        Node* prev = nullptr;

        if (temp->data == val) {
            head = temp->next;
            delete temp;
            updateHashDelete(val);
            size--;
            return true;
        }

        while (temp && temp->data != val) {
            prev = temp;
            temp = temp->next;
        }

        if (!temp) return false;  // Element not found

        prev->next = temp->next;
        updateHashDelete(temp->data);
        delete temp;
        size--;
        return true;
    }

    // Fast equivalence check based on cumulative hash
    bool isEquivalent(const LinkedList& other) const {
        if (this->size != other.size) return false;
        return this->cumulativeHash == other.cumulativeHash;
    }

    // Utility function to print the list (for debugging)
    void printList() const {
        Node* temp = head;
        while (temp) {
            std::cout << temp->data << " -> ";
            temp = temp->next;
        }
        std::cout << "NULL\n";
    }
};


