#include <iostream>
#include <vector>
#include <unordered_map>
#include <random>
#include <openssl/sha.h>

// Function to generate a random dataset of size 1000
std::vector<int> generateDataset(int size) {
    std::vector<int> dataset(size);
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(1000000000, 9999999999); // Example: phone numbers

    for (int i = 0; i < size; ++i) {
        dataset[i] = dis(gen);
    }
    return dataset;
}

// Hash function 1: h(x) = x mod 50
int hashFunction1(int x) {
    return x % 50;
}

// Hash function 2: h(x) = ((ax+b) mod p) mod 50
int hashFunction2(int x, int a, int b, int p) {
    return ((a * x + b) % p) % 50;
}

// Hash function 3: h(x) = SHA-256(x) mod 50
int hashFunction3(int x) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, &x, sizeof(x));
    SHA256_Final(hash, &sha256);

    int hashValue = 0;
    for (int i = 0; i < SHA256_DIGEST_LENGTH; ++i) {
        hashValue = (hashValue * 256 + hash[i]) % 50;
    }
    return hashValue;
}

